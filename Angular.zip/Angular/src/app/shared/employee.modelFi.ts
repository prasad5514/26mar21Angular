export class EmployeeC {
    id: string;
    userName: string;
    email: string;
    phone: string;
    gender: string;
    age: number;
}
